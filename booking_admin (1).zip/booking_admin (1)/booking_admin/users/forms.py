from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import get_user_model
from .models import CustomUser
# from simplemathcaptcha.fields import MathCaptchaField

User = get_user_model()


class RegistrationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email']

    # def __init__(self, *args, **kwargs):
    #     super().__init__(*args, **kwargs)
    #     self.fields.pop('password1', None)
    #     self.fields.pop('password2', None)


class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
    # captcha = MathCaptchaField()


class UpdateProfile(forms.ModelForm):
    username = forms.CharField(max_length=255, required=True)
    email = forms.EmailField(required=True)

    class Meta:
        model = CustomUser
        fields = ['username', 'email']


# class InMemoryUser:
#     def __init__(self, username, is_staff=False, is_superuser=False):
#         self.username = username
#         self.is_staff = is_staff
#         self.is_superuser = is_superuser
#
#     @property
#     def is_authenticated(self):
#         return True
