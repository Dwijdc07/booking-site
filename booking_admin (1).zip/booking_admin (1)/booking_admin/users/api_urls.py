from django.urls import path
from .views import test_api, test2_api
urlpatterns = [
    path('first_api/',test_api, name="test_api"),
    path('second_api/',test2_api,name="test2_api")
]