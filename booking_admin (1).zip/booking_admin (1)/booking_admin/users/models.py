from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import check_password
from .utils import generate_qr_code

# Create your models here.


class CustomUser(AbstractUser):
    # name = models.CharField(max_length=50)
    email = models.EmailField(max_length=150)
    username = models.CharField(max_length=10, unique=True)

    def __str__(self):
        return self.username


class EventCard(models.Model):
    title = models.CharField(max_length=50)
    description = models.TextField()
    image = models.ImageField(upload_to='event_images/', default="")
    artist = models.CharField(max_length=150, default="", blank=True)
    date = models.DateField()
    time = models.TimeField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    location = models.CharField(max_length=50)
    seats = models.IntegerField(default=30)

    # def __str__(self):
    #     return self.title


class Booking(models.Model):
    event_id = models.ForeignKey(EventCard, on_delete=models.CASCADE, null=False)
    user_id = models.ForeignKey(CustomUser, on_delete=models.CASCADE, null=False)
    quantity = models.IntegerField(null=False)
    payment = models.BooleanField(null=False)
    qr_code = models.ImageField(upload_to='qr_code_image/',default="")


    # def save(self,*args,**kwargs):
    #     if not self.qr_code:
    #         data = f"Tickets: {self.quantity}, user_id: {self.user_id}, event_id: {self.event_id}"
    #         self.qr_code = generate_qr_code(data)
    #     super().save(*args,**kwargs)













# def fetch_user():
#     User = get_user_model()
#     try:
#         user = User.objects.get(username="dwij1")
#         print("User fetched:", user, user.password)
#         user.set_password("test@123")  # Replace "your_new_password" with the new password
#         user.save()
#         # is_correct = check_password('test@123', user.password)
#         # print("Password correct:", is_correct)
#         # print("save")
#     except User.DoesNotExist:
#         print("User with username 'dwij' does not exist.")

# print("fetch",fetch_user())
