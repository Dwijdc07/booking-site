import qrcode
from io import BytesIO
# from django.core.files import File
# import os
# from django.conf import settings
# from django.core.files.storage import default_storage



def generate_qr_code(data):
    qr = qrcode.QRCode(version=1,error_correction=qrcode.constants.ERROR_CORRECT_L,box_size=10,border=2)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color='black', back_color='white')
    img_byte_arr = BytesIO()
    img.save(img_byte_arr)
    img_byte_arr.seek(0)
    return img_byte_arr

