from datetime import datetime, timedelta
from django.core.files.storage import default_storage
from django.conf import settings
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from .forms import RegistrationForm, LoginForm, UpdateProfile
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import EventCard, CustomUser, Booking
from django.core.mail import send_mail
from django.urls import reverse
import os
from .utils import generate_qr_code


# Create your views here.
def register_view(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            print("user", user)
            login(request, user)
            messages.success(request, "Registration Success")
            return redirect('home')
    else:
        form = RegistrationForm()
    return render(request, 'registration.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            username = form.cleaned_data.get('username')
            print("username_login", username)
            messages.success(request, "Updated successfully")
            # return redirect(request.GET.get('next', 'home'), {"username": username})
            return redirect(f"{reverse('home')}?username={username}")
        else:
            pass
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})


@login_required(login_url='register')
def logout_view(request):
    logout(request)
    messages.success(request, 'Logout successfully')
    return redirect('login')


@login_required(login_url='register')
def home_view(request):
    today_day = datetime.today()
    search = request.GET.get('search')
    print("search", search)
    all_date = []
    for i in range(8):
        day_insert = (today_day
                      + timedelta(days=i))
        print("day_insert", day_insert)
        all_date.append(str(day_insert.date()))
    if search is not None:
        cards = EventCard.objects.filter(description__icontains=search, date__gt=today_day.date()).order_by('date')
        print("card_search", cards)

    else:
        cards = EventCard.objects.filter(date__gt=today_day.date()).order_by('date')

    for card in cards:
        if card.date >= datetime.today().date():

            booking = Booking.objects.filter(event_id_id=card.id)
            total = 0
            for book in booking:
                quantity = book.quantity
                total = quantity + total
            available_seats = card.seats - total
            if available_seats > 0:
                setattr(card, "tickets", available_seats)
            else:
                setattr(card, "tickets", 0)
        else:
            continue

    return render(request, 'home.html', {"cards": cards, "all_date": all_date})


def event_data(request):
    select_date = datetime.strptime(request.GET.get('date'), "%Y-%m-%d").date()
    today_day = datetime.today().date()
    all_date = []
    for i in range(8):
        day_insert = today_day + timedelta(days=i)
        print("day_insert", day_insert)
        all_date.append(str(day_insert))

    print("select_date", select_date, type(select_date))
    print("today", today_day, type(today_day))
    date_data = EventCard.objects.filter(date=select_date)
    for card in date_data:
        if card.date >= datetime.today().date():

            booking = Booking.objects.filter(event_id_id=card.id)
            total = 0
            for book in booking:
                quantity = book.quantity
                total = quantity + total
            available_seats = card.seats - total
            if available_seats > 0:
                setattr(card, "tickets", available_seats)
            else:
                setattr(card, "tickets", 0)
        else:
            continue
    print("date_date", date_data, type(date_data))
    return render(request, 'filter_events.html', {'cards': date_data, "all_date": all_date, "select_date": select_date})


def send_email1(price, email):
    subject = 'From Booking'
    messages = f"Email For confirmation \n "
    from_email = "dwijkarmaleen@gmail.com"
    recipient_list = [email]
    print("email", subject, messages, from_email, price, recipient_list)
    send_mail(subject, messages, from_email, recipient_list)


def store_event_data(event_id_instance, user_id_instance, quantity, payment):
    print("store")
    print(event_id_instance, user_id_instance, quantity, payment)
    event_id = EventCard.objects.get(id=event_id_instance)
    user_id = CustomUser.objects.get(id=user_id_instance)

    store_data = Booking(event_id=event_id, user_id=user_id, quantity=quantity, payment=payment)
    store_data.save()
    ticket_id = store_data.id
    print("ticket_id", ticket_id, quantity, user_id, event_id)
    data = f"https://www.google.co.in/"
    qr_code_image = generate_qr_code(data)
    qr_code_filename = f"qr_code/qr_code_image_{ticket_id}.png"
    print("qr_code_filename", qr_code_filename)
    qr_code_dir = os.path.dirname(qr_code_filename)
    if not os.path.exists(os.path.join(settings.MEDIA_ROOT, qr_code_dir)):
        os.makedirs(os.path.join(settings.MEDIA_ROOT, qr_code_dir))

    with default_storage.open(qr_code_filename, 'wb') as f:
        f.write(qr_code_image.read())
    store_data.qr_code = qr_code_filename
    store_data.save()
    qr_code_url = f"{settings.MEDIA_URL}{qr_code_filename}"
    print("qr_code_url", qr_code_url)
    return qr_code_url


def book_event(request):
    user_email = request.POST.get('email')
    event_id = request.POST.get('event_id')
    if user_email:
        user = CustomUser.objects.filter(email=user_email).first()
        if user:
            user_id = user.id
            qr_code_url = None
            if request.method == 'POST':  # Check if the request method is POST
                price = request.POST.get('price')
                email = request.POST.get('email')
                quantity = request.POST.get('quantity')
                # send_email1(price,email)
                qr_code_url = store_event_data(event_id, user_id, quantity, True)
            return render(request, 'book_event.html', {"qr_code_url": qr_code_url})
        else:
            messages.error(request, "Email is required to book the event.")
            return redirect(home_view)
    else:
        messages.error(request, "Email is required to book the event.")
        return redirect(home_view)


def book_form(request):
    store_id = request.GET.get('id', None)
    event_data = EventCard.objects.filter(id=store_id).first()
    return render(request, 'book_form.html', {'event': event_data, 'event_id': event_data.id})


def profile_view(request):
    print("hello")
    name = request.GET.get('username')
    print("name", name)
    user_data = CustomUser.objects.filter(username=name).first()
    print("data", user_data)
    email = user_data.email
    date_join = user_data.date_joined
    user_id = user_data.id
    booking_data = Booking.objects.filter(user_id_id=user_id)
    booking_data.payment = False
    print("boking1", booking_data)
    # event_titles = []
    for i in booking_data:
        event_id_id = i.event_id_id
        event_data = EventCard.objects.filter(id=event_id_id).first()
        event_title = event_data.title
        event_date = event_data.date
        i.event_title = event_title
        i.event_date = event_date
    return render(request, 'profile.html',
                  {'name': name, 'email': email, 'date_join': date_join, 'booking_data': booking_data})


def update_profile(request):
    email = request.GET.get('email')
    user = CustomUser.objects.filter(email=email).first()
    print("email", email)
    if request.method == 'POST':
        update_form = UpdateProfile(request.POST, instance=user)
        if update_form.is_valid():
            updated_username = update_form.cleaned_data.get('username')
            print("updated_username", updated_username)
            updated_email = update_form.cleaned_data.get('email')
            print("updated_email", updated_email)
            user.username = updated_username
            user.email = updated_email
            user.save()
            print("user", user)
            login(request, user)
            messages.success(request, "Update Successfully")

            return render(request, 'alert_success.html')
    else:
        update_form = UpdateProfile(instance=user)
    return render(request, 'update_profile.html', {'form': update_form})


## API Integration
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status


@api_view(['GET'])
def test_api(request):
    print("hello")
    return Response({"message": "successfully working"})


@api_view(['POST'])
def test2_api(request):
    print("hello")
    return Response({"message": "successfully working"})
