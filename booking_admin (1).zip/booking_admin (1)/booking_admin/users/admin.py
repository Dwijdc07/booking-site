from django.contrib import admin
from .models import EventCard, Booking


# Register your models here.

class CardAdmin(admin.ModelAdmin):
    list_display = ('title', 'description', 'image', 'artist', 'date', 'time', 'price', 'location')
    search_fields = ('title', 'artist', 'date')


admin.site.register(EventCard, CardAdmin)
admin.site.register(Booking)
